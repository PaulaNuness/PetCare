package com.example.demo.Interface;

import java.util.Map;

public class InventarioPOJO {

	private int idInventario;
	private String nombreMedicamento;
	private String recomendaciones;
	
	/****************************************************************************************************/
	
	public InventarioPOJO() {
		
	}
	
	/****************************************************************************************************/
	
	public InventarioPOJO(int idInventario, String nombreMedicamento, String recomendaciones) {
		super();
		this.idInventario = idInventario;
		this.nombreMedicamento = nombreMedicamento;
		this.recomendaciones = recomendaciones;
	}
	
	/****************************************************************************************************/
	
	public InventarioPOJO(Map<String,Object>aux) throws Exception{
		this.idInventario=(Integer) aux.get("IdInventario");
		this.nombreMedicamento=(String) aux.get("NombreMedicamento");
		this.recomendaciones=(String) aux.get("Recomendaciones");

	}
	
	/****************************************************************************************************/
	
	public int getIdInventario() {
		return idInventario;
	}

	public void setIdInventario(int idInventario) {
		this.idInventario = idInventario;
	}

	public String getNombreMedicamento() {
		return nombreMedicamento;
	}

	public void setNombreMedicamento(String nombreMedicamento) {
		this.nombreMedicamento = nombreMedicamento;
	}

	public String getRecomendaciones() {
		return recomendaciones;
	}

	public void setRecomendaciones(String recomendaciones) {
		this.recomendaciones = recomendaciones;
	}

	/****************************************************************************************************/

	@Override
	public String toString() {
		return "InventarioPOJO [idInventario=" + idInventario + ", nombreMedicamento=" + nombreMedicamento
				+ ", recomendaciones=" + recomendaciones + "]";
	}

	/****************************************************************************************************/
	
}
