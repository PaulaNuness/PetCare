package com.example.demo.Datos;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.example.demo.Interface.InventarioPOJO;

public class BBDD_Inventario {
	
/********************************************************************************************************************/	
	//metodo para buscar todos los medicamentos da base de datos
	 public static List<InventarioPOJO> getMedicamentos() {
		 
	        List<InventarioPOJO> clientes = new ArrayList<>();
	        
	        Connection conn = null;
	        PreparedStatement query = null;
	        ResultSet result = null;
   	    
	        try {
		    	// Obter conexão com o banco de dados
		        conn = ConexionBD.obterConexao();
	        	
		        // Consulta SQL	
	            String sql = "SELECT * FROM inventario ";
	            
	            query = conn.prepareStatement(sql);
	           // Executar a consulta
		        result = query.executeQuery();

	           while (result.next()) {
	        	   InventarioPOJO cliente = new InventarioPOJO();
	        	   		cliente.setIdInventario(result.getInt(1));
	        	   		cliente.setNombreMedicamento(result.getString(2));
	        	   		cliente.setRecomendaciones(result.getString(3));
	        	   		clientes.add(cliente);
	                }
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	        return clientes;
	    }
/********************************************************************************************************************/

}
