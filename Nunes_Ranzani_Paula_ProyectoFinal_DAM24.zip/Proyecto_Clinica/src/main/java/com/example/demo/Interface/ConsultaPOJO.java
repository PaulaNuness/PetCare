package com.example.demo.Interface;

import java.util.Map;

public class ConsultaPOJO {

	private int idConsulta;
	private int idUsuario;
	private int idPaciente;
	private String fecha;
	private String hora;
	private String descripcion;
	
	/****************************************************************************************************/
	public ConsultaPOJO() {

	}
	
	/****************************************************************************************************/
	public ConsultaPOJO(int idConsulta, int idUsuario, int idPaciente, String fecha, String hora, String descripcion) {

		this.idConsulta = idConsulta;
		this.idUsuario = idUsuario;
		this.idPaciente = idPaciente;
		this.fecha = fecha;
		this.hora = hora;
		this.descripcion = descripcion;
	}
	
	/****************************************************************************************************/
	
	public ConsultaPOJO(Map<String,Object>aux) throws Exception{
		this.idConsulta=(Integer) aux.get("IdConsulta");
		this.idUsuario=(Integer) aux.get("IdUsuario");
		this.idPaciente=(Integer) aux.get("IdPaciente");
		this.fecha=(String) aux.get("Fecha");
		this.hora=(String) aux.get("Hora");
		this.descripcion=(String) aux.get("Descripcion");

	}
	
	/****************************************************************************************************/

	public int getIdConsulta() {
		return idConsulta;
	}

	public void setIdConsulta(int idConsulta) {
		this.idConsulta = idConsulta;
	}

	public int getIdUsuario() {
		return idUsuario;
	}

	public void setIdUsuario(int idUsuario) {
		this.idUsuario = idUsuario;
	}

	public int getIdPaciente() {
		return idPaciente;
	}

	public void setIdPaciente(int idPaciente) {
		this.idPaciente = idPaciente;
	}

	public String getFecha() {
		return fecha;
	}

	public void setFecha(String fecha) {
		this.fecha = fecha;
	}

	public String getHora() {
		return hora;
	}

	public void setHora(String hora) {
		this.hora = hora;
	}

	public String getDescripcion() {
		return descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	/****************************************************************************************************/

	@Override
	public String toString() {
		return "ConsultaPOJO [idConsulta=" + idConsulta + ", idUsuario=" + idUsuario + ", idPaciente=" + idPaciente
				+ ", fecha=" + fecha + ", hora=" + hora + ", descripcion=" + descripcion + "]";
	}

	/****************************************************************************************************/
	
}
