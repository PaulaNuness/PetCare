package com.example.demo.Negocio;

import java.util.ArrayList;
import java.util.List;

import com.example.demo.Datos.BBDD_Inventario;
import com.example.demo.Interface.InventarioPOJO;

public class Inventario {
	
/*******************************************************************************************************************/
	//metodo para buscar todos los medicamentos da base de datos
	 public static List<InventarioPOJO> getClientes() {
		 List<InventarioPOJO> usuarios = new ArrayList<>();
		 try {
			 usuarios = BBDD_Inventario.getMedicamentos();
		 }catch(Exception e){
				e.printStackTrace();
			}
		return usuarios;
		 
	 }
/*******************************************************************************************************************/

}
