package com.example.demo.Datos;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.example.demo.Interface.ConsultaPOJO;
import com.example.demo.Interface.InventarioPOJO;

public class BBDD_Consulta {
	/********************************************************************************************************************/	
	//metodo para buscar todos los medicamentos da base de datos
	 public static List<ConsultaPOJO> getConsultas() {
		 
	        List<ConsultaPOJO> clientes = new ArrayList<>();
	        
	        Connection conn = null;
	        PreparedStatement query = null;
	        ResultSet result = null;
   	    
	        try {
		    	// Obter conexão com o banco de dados
		        conn = ConexionBD.obterConexao();
	        	
		        // Consulta SQL	
	            String sql = "SELECT * FROM consultas ";
	            
	            query = conn.prepareStatement(sql);
	           // Executar a consulta
		        result = query.executeQuery();

	           while (result.next()) {
	        	   ConsultaPOJO cliente = new ConsultaPOJO();
	        	   		cliente.setIdConsulta(result.getInt(1));
	        	   		cliente.setIdUsuario(result.getInt(2));
	        	   		cliente.setIdPaciente(result.getInt(3));
	        	   		cliente.setFecha(result.getString(4));
	        	   		cliente.setHora(result.getString(5));
	        	   		cliente.setDescripcion(result.getString(6));
	        	   		
	        	   		clientes.add(cliente);
	                }
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	        return clientes;
	    }
/********************************************************************************************************************/

}
