package com.example.demo.Datos;

//nombre y cuerpo del mensage
public record ChatMessage(String username, String body) {
}
