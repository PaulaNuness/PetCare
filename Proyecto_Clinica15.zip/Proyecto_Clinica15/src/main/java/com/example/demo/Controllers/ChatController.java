package com.example.demo.Controllers;

import com.example.demo.Datos.BBDD_Usuario;
import com.example.demo.Datos.ChatMessage;
import com.example.demo.Datos.JoinMessage;
import com.example.demo.Interface.ChatPOJO;
import com.example.demo.Interface.UsuarioPOJO;
import com.example.demo.Negocio.Chat;
import com.example.demo.Negocio.Usuario;

import jakarta.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.context.event.EventListener;
import org.springframework.messaging.handler.annotation.MessageMapping;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.messaging.handler.annotation.SendTo;
import org.springframework.messaging.simp.SimpMessageHeaderAccessor;
import org.springframework.messaging.simp.SimpMessageSendingOperations;
import org.springframework.messaging.simp.stomp.StompHeaderAccessor;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.socket.messaging.SessionDisconnectEvent;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Collectors;

@Controller
public class ChatController {

    @Autowired
    private SimpMessageSendingOperations ops;
    private static final Map<String, Map<String, Object>> sessions = new ConcurrentHashMap<>();

    @Autowired
    private MessageSource meassageSource;

    @Autowired
    private HttpServletRequest request;

  /********************************************************************************************************************/
    //para abrir la vista
    @RequestMapping("/chat")
    public ModelAndView Usuario() {
        ModelAndView mv = new ModelAndView();
        Map<String, Object> model = new HashMap<>();
        try {
            mv = new ModelAndView("chat", "model", model);
        } catch (Exception e) {
            e.getMessage();
        }
        return mv;
    }
    
    /********************************************************************************************************************/
  //metodo para cuando un usuario se una al chat
    @MessageMapping("/join")
    public void onJoin(
    	//recebe los parametros
        @Payload JoinMessage message,
        SimpMessageHeaderAccessor accessor
    ) {
        Map<String, Object> model = new HashMap<>();
        String sessionId = accessor.getSessionId();
        Map<String, Object> sessionAttributes = accessor.getSessionAttributes();//atributos de la ssesion, ejemplo, email, contraseña
        String username = message.username();
        sessionAttributes.put("username", username);
        sessions.put(sessionId, sessionAttributes);

        // Send welcome message
        var msg = new ChatMessage(username, "\" -- entro en el chat -- \"");
        this.ops.convertAndSend("/topic/responses", msg);

        // Send updated user list
        var usersMsg = new ChatMessage(getUserNames(), "");
        this.ops.convertAndSend("/topic/users", usersMsg);
    }

    /********************************************************************************************************************/
  //metodo para las respuestas
    @MessageMapping("/chat")
    @SendTo("/topic/responses")
    public ChatMessage onMessage(
        @Payload ChatMessage message,
        SimpMessageHeaderAccessor accessor
    ) {
    	
        return message;
    }

    /********************************************************************************************************************/
  //para indicar que el usuario a salindo
    @EventListener
    public void disconnectListener(SessionDisconnectEvent event) {
        StompHeaderAccessor headerAccessor = StompHeaderAccessor.wrap(event.getMessage());
        String username = (String) headerAccessor.getSessionAttributes().get("username");
        if (username != null) {
            var msg = new ChatMessage(username, " -- salio del chat -- ");
            ops.convertAndSend("/topic/responses", msg);
            sessions.remove(headerAccessor.getSessionId());
            var updateUserList = new ChatMessage(getUserNames(), "");
            ops.convertAndSend("/topic/users", updateUserList);
        }
    }

    /********************************************************************************************************************/
    
    private String getUserNames() {
        return sessions.values().stream()
            .map(v -> v.get("username"))
            .map(String::valueOf)
            .collect(Collectors.joining(", "));
    }
    
    /********************************************************************************************************************/
	//mapeando para armazenar chat
	@RequestMapping("/armazenarChat.json")
	@ResponseBody
	public Object crearUsuario(
	        @RequestParam(value="nombreUsuario") String nombreUsuario,
	        @RequestParam(value="conversacion") String conversacion
	        ){

	    Map<String,Object> model = new HashMap<>();
	    try {
	    	int idUsuario = BBDD_Usuario.retornarIdUsuario(nombreUsuario);
	    	
	    	ChatPOJO datos = new ChatPOJO(idUsuario,conversacion);
	    	Chat.insertarChat(datos);
	        model.put("chat", "OK");
	        model.put("success", true);
	        
	    } catch(Exception e) {
	        e.printStackTrace();
	        model.put("mensaje", "Ocurrió un error al crear/modificar el usuario");
	        model.put("success", false);
	    }
	    return model;
	}

/********************************************************************************************************************/
}
