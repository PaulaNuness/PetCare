package com.example.demo.Negocio;

import com.example.demo.Datos.BBDD_Chat;
import com.example.demo.Interface.ChatPOJO;

public class Chat {
	
	//mapeando para insertar chat
	public static void insertarChat(ChatPOJO  datos) {
		try {
			 
			BBDD_Chat.insertarChat(datos);
			
		}catch(Exception e){
			e.printStackTrace();
		}
	}
/********************************************************************************************************************/	

}
