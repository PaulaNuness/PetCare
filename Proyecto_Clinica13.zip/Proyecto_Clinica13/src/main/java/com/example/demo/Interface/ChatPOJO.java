package com.example.demo.Interface;

import java.util.Map;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class ChatPOJO {
	
	private int idChat;
	private int idUsuario;
	private String descripcion;
	
	/********************************************************************************************************************/
	public ChatPOJO() {

	}
	
	/********************************************************************************************************************/
	
	public ChatPOJO(int idUsuario, String descripcion) {
		
		this.idUsuario = idUsuario;
		this.descripcion = descripcion;
	}
	
	/********************************************************************************************************************/	
	public ChatPOJO(Map<String,Object>aux) throws Exception{
		this.idUsuario=(Integer) aux.get("IdUsuario");
		this.descripcion=(String) aux.get("Descricion");
		this.idChat=(Integer) aux.get("IdChat");
		
	}
	/********************************************************************************************************************/
	public int getIdUsuario() {
		return idUsuario;
	}

	public void setIdUsuario(int idUsuario) {
		this.idUsuario = idUsuario;
	}

	public String getDescripcion() {
		return descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}
	
	public int getIdChat() {
		return idChat;
	}

	public void setIdChat(int idChat) {
		this.idChat = idChat;
	}

	/********************************************************************************************************************/
	@Override
	public String toString() {
		return "ChatPOJO [idChat=" + idChat + ", idUsuario=" + idUsuario + ", descripcion=" + descripcion + "]";
	}



	/********************************************************************************************************************/
}
