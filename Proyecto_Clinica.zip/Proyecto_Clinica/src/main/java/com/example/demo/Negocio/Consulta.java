package com.example.demo.Negocio;

import java.util.ArrayList;
import java.util.List;

import com.example.demo.Datos.BBDD_Consulta;
import com.example.demo.Datos.BBDD_Inventario;
import com.example.demo.Interface.ConsultaPOJO;
import com.example.demo.Interface.InventarioPOJO;

public class Consulta {
	/*******************************************************************************************************************/
	//metodo para buscar todos las consultas da base de datos
	 public static List<ConsultaPOJO> getClientes() {
		 List<ConsultaPOJO> usuarios = new ArrayList<>();
		 try {
			 usuarios = BBDD_Consulta.getConsultas();
		 }catch(Exception e){
				e.printStackTrace();
			}
		return usuarios;
		 
	 }
/*******************************************************************************************************************/

}
