package com.example.demo.Datos;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.example.demo.Interface.ChatPOJO;
import com.example.demo.Interface.UsuarioPOJO;

public class BBDD_Chat {
	
/********************************************************************************************************************/

	//metodo para insertar chat en la base de datos 
	public static void insertarChat(ChatPOJO  datos) {
		
		Connection conn = null;
        PreparedStatement query = null;
        
		try {
			
			// Obter conexão com o banco de dados
            conn = ConexionBD.obterConexao();
            
           // Consulta SQL para inserir um novo usuário
            String sql = "INSERT INTO chat (IdUsuario, Descripcion) VALUES (?, ?)";

            query = conn.prepareStatement(sql);

            // Preencher os parâmetros da consulta com os dados do POJO
            query.setInt(1, datos.getIdUsuario());
            query.setString(2, datos.getDescripcion());
            
            // Executar a consulta
            query.executeUpdate();
            System.out.println("Chat inserido com sucesso.");
			
         
		}catch(Exception e){
            e.printStackTrace();
            System.out.println("Erro ao inserir usuário: " + e.getMessage());
		}finally {
            // Fechar a conexão e o statement
            ConexionBD.fecharConexao(conn);
            if (query != null) {
                try {
                    query.close();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
		}
	}
	
/********************************************************************************************************************/	

}
