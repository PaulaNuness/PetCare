package com.example.demo.Datos;

//el nombre como parametro
public record JoinMessage(String username) {
}
